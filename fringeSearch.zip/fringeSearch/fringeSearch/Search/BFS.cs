﻿/****************************
*   BFS
 ****************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace fringeSearch.Search
{
    class BFS
    {
        private Node[,] Map;
        private Point S, G;
        private int Row, Col;
        private List<string> Fringe;
        private List<Point> Extended;
        private List<string> Report;
        //---------------------------
        public void Init(String[] File)
        {
            Report = new List<string>();
            Extended = new List<Point>();
            Fringe = new List<string>();
            char[] split = { ' ' };
            List<string[]> types = new List<string[]>();
            Row = File.Length;
            for (int i = 0; i < Row; i++)
            {
                types.Add(File[i].Split(split));
            }
            Col = types[0].Length;
            Map = new Node[Row, Col];
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Col; j++)
                {
                    Map[i, j] = new Node(int.Parse(types[i][j]), 100000, int.MaxValue, 'N');
                    if (Map[i, j].type == 1) S = new Point(i, j);
                    if (Map[i, j].type == 2) G = new Point(i, j);
                }
            }
        }
        //---------------------------
        private bool IsTarget(Point P)
        {
            return P == G;
        }
        private bool CanGo(Point P)
        {
            bool R = (((P.X >= 0) && (P.X < Row)) && ((P.Y >= 0) && (P.Y < Col)));
            if (R)
            {
                if (Map[P.X, P.Y].type >= 3) R = false;
            }
            return R;
        }
        private bool IsBetter(Point P, int C, char d)
        {
            if (CanGo(P))
            {
                if (Map[P.X, P.Y].cost > C)
                {
                    Map[P.X, P.Y].cost = C;
                    Map[P.X, P.Y].dir = d;
                    Map[P.X, P.Y].Visited = false;
                    return true;
                }
            }
            return false;
        }
        //---------------------------
        private Point Move(Point P, char d)
        {
            int x = (d == 'U') ? -1 : (d == 'D') ? +1 : 0;
            int y = (d == 'L') ? -1 : (d == 'R') ? +1 : 0;
            return new Point(P.X + x, P.Y + y);
        }
        //---------------------------
        public void BFS_Search()
        {
            Extended.Add(S);
            Report.Add("S");
            int idx = 0;            
            int flag = -1;
            int step = 1;
            Map[S.X, S.Y].cost = 0;
            Point P, L, R, T, D;            
            String selected = " (0*)";
            Fringe.Add("---- STEP 0 -------------");
            Fringe.Add(Report[idx] + selected);
            while (idx < Extended.Count)
            {                
                P = Extended[idx];                
                if (IsTarget(P)) break;
                L = Move(P, 'L');
                T = Move(P, 'U');
                R = Move(P, 'R');
                D = Move(P, 'D');
                if (!IsBetter(L, Map[P.X, P.Y].cost + 1, 'L')) { L.X = L.Y = -1; }
                else { Extended.Add(L); Report.Add(Report[idx] + "L"); }
                if (!IsBetter(T, Map[P.X, P.Y].cost + 1, 'U')) { T.X = T.Y = -1; }
                else { Extended.Add(T); Report.Add(Report[idx] + "U"); }
                if (!IsBetter(R, Map[P.X, P.Y].cost + 1, 'R')) { R.X = R.Y = -1; }
                else { Extended.Add(R); Report.Add(Report[idx] + "R"); }
                if (!IsBetter(D, Map[P.X, P.Y].cost + 1, 'D')) { D.X = D.Y = -1; }
                else { Extended.Add(D); Report.Add(Report[idx] + "D"); }                
                for (int i = 0; i < 4; i++)
                {
                    flag = -1;
                    selected = " (" + step.ToString() + "*)";
                    if (L.X > -1)
                    {
                        flag++;
                        if (flag == i)
                        {
                            step++;
                            Fringe.Add("---- STEP " + step.ToString() + " -------------");
                            Fringe.Add(Report[idx] + "L" + selected);
                            if (T.X > -1) Fringe.Add(Report[idx] + "U");
                            if (R.X > -1) Fringe.Add(Report[idx] + "R");
                            if (D.X > -1) Fringe.Add(Report[idx] + "D");
                            if (IsTarget(L))
                            {
                                idx = Extended.Count;
                                break;
                            }
                        }
                    }
                    if (T.X > -1)
                    {
                        flag++;
                        if (flag == i)
                        {
                            step++;
                            Fringe.Add("---- STEP " + step.ToString() + " -------------");
                            if (L.X > -1) Fringe.Add(Report[idx] + "L");                            
                            Fringe.Add(Report[idx] + "U" + selected);
                            if (R.X > -1) Fringe.Add(Report[idx] + "R");
                            if (D.X > -1) Fringe.Add(Report[idx] + "D");
                            if (IsTarget(T))
                            {
                                idx = Extended.Count;
                                break;
                            }
                        }
                    }
                    if (R.X > -1)
                    {
                        flag++;
                        if (flag == i)
                        {
                            step++;
                            Fringe.Add("---- STEP " + step.ToString() + " -------------");
                            if (L.X > -1) Fringe.Add(Report[idx] + "L");
                            if (T.X > -1) Fringe.Add(Report[idx] + "U");                            
                            Fringe.Add(Report[idx] + "R" + selected);
                            if (D.X > -1) Fringe.Add(Report[idx] + "D");
                            if (IsTarget(R))
                            {
                                idx = Extended.Count;
                                break;
                            }
                        }
                    }
                    if (D.X > -1)
                    {
                        flag++;
                        if (flag == i)
                        {
                            step++;
                            Fringe.Add("---- STEP " + step.ToString() + " -------------");
                            if (L.X > -1) Fringe.Add(Report[idx] + "L");
                            if (T.X > -1) Fringe.Add(Report[idx] + "U");
                            if (R.X > -1) Fringe.Add(Report[idx] + "R");
                            Fringe.Add(Report[idx] + "D" + selected);
                            if (IsTarget(D))
                            {
                                idx = Extended.Count;
                                break;
                            }
                        }
                    }
                }
                idx++;
            }            
        }        
        //---------------------------
        public string GetPath()
        {
            Point P = G;
            string path = "";
            char c = ' ';
            while (P.X != S.X || P.Y != S.Y)
            {
                path += Map[P.X, P.Y].dir.ToString();
                switch (Map[P.X, P.Y].dir)
                {
                    case 'L': c = 'R'; break;
                    case 'U': c = 'D'; break;
                    case 'R': c = 'L'; break;
                    case 'D': c = 'U'; break;
                }
                P = Move(P, c);
            }
            return path;
        }
        public List<Point> GetExtended()
        {
            return Extended;
        }
        public List<string> GetFringe()
        {
            return Fringe;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace fringeSearch.Search
{
    class AStar
    {
        private Node[,] Map;
        private Point S, G;
        private int Row, Col;
        private List<string> Fringe;
        private List<Point> Extended;
        private List<string> Report;
        //---------------------------
        private void SetHue()
        {
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Col; j++)
                {
                    Map[i, j].hue = Math.Abs(i - G.X) + Math.Abs(j - G.Y);
                }
            }
        }
        public void Init(String[] File)
        {
            Report = new List<string>();
            Extended = new List<Point>();
            Fringe = new List<string>();
            char[] split = { ' ' };
            List<string[]> types = new List<string[]>();
            Row = File.Length;
            for (int i = 0; i < Row; i++)
            {
                types.Add(File[i].Split(split));
            }
            Col = types[0].Length;
            Map = new Node[Row, Col];
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Col; j++)
                {
                    Map[i, j] = new Node(int.Parse(types[i][j]), 100000, int.MaxValue, 'N');
                    if (Map[i, j].type == 1) S = new Point(i, j);
                    if (Map[i, j].type == 2) G = new Point(i, j);
                }
            }
            SetHue();
        }
        //---------------------------
        private bool IsTarget(Point P)
        {
            return P == G;
        }
        private bool CanGo(Point P)
        {
            bool R = (((P.X >= 0) && (P.X < Row)) && ((P.Y >= 0) && (P.Y < Col)));
            if (R)
            {
                if (Map[P.X, P.Y].type >= 3) R = false;
            }
            return R;
        }
        private bool IsBetter(Point P, int C, char d)
        {
            if (CanGo(P))
            {
                if (Map[P.X, P.Y].cost > C)
                {
                    Map[P.X, P.Y].cost = C;
                    Map[P.X, P.Y].dir = d;
                    Map[P.X, P.Y].Visited = false;
                    return true;
                }
            }
            return false;
        }
        //---------------------------
        private Point Move(Point P, char d)
        {
            int x = (d == 'U') ? -1 : (d == 'D') ? +1 : 0;
            int y = (d == 'L') ? -1 : (d == 'R') ? +1 : 0;
            return new Point(P.X + x, P.Y + y);
        }
        //---------------------------
        private Point FindMin()
        {
            Point p = new Point();
            int min = int.MaxValue;
            int value = 0;
            for (int i = 0; i < Extended.Count; i++)
            {
                value = Map[Extended[i].X, Extended[i].Y].cost + Map[Extended[i].X, Extended[i].Y].hue;
                if (value < min && !Map[Extended[i].X, Extended[i].Y].Visited && CanGo(Extended[i]))
                {
                    min = value;
                    p = Extended[i];
                }
            }
            return p;
        }
        public void AStar_Search()
        {
            Point P = S;
            Map[P.X, P.Y].cost = 0;
            Point L, R, T, D;
            Extended = new List<Point>();
            Extended.Add(S);
            int step = 0;
            while (!Map[G.X, G.Y].Visited)
            {
                Fringe.Add("---- STEP " + step.ToString() + " -------------");
                Fringe.Add(P.ToString() + " (" + step.ToString() + "*)");
                step++;
                Map[P.X, P.Y].Visited = true;
                L = Move(P, 'L');
                T = Move(P, 'U');
                R = Move(P, 'R');
                D = Move(P, 'D');
                if (IsBetter(L, Map[P.X, P.Y].cost + 1, 'L')) Extended.Add(L);
                if (IsBetter(R, Map[P.X, P.Y].cost + 1, 'R')) Extended.Add(R);
                if (IsBetter(D, Map[P.X, P.Y].cost + 1, 'D')) Extended.Add(D);
                if (IsBetter(T, Map[P.X, P.Y].cost + 1, 'U')) Extended.Add(T);
                P = FindMin();
            }
        }
        //---------------------------
        public string GetPath()
        {
            Point P = G;
            string path = "";
            char c = ' ';
            while (P.X != S.X || P.Y != S.Y)
            {
                path += Map[P.X, P.Y].dir.ToString();
                switch (Map[P.X, P.Y].dir)
                {
                    case 'L': c = 'R'; break;
                    case 'U': c = 'D'; break;
                    case 'R': c = 'L'; break;
                    case 'D': c = 'U'; break;
                }
                P = Move(P, c);
            }
            return path;
        }
        public List<Point> GetExtended()
        {
            return Extended;
        }
        public List<string> GetFringe()
        {
            return Fringe;
        }
    }
}
